import javax.xml.bind.DatatypeConverter;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        List<Double> sorszamok = new ArrayList<>();
        List<Double> allomasok = new ArrayList<>();
        List<Double> ora = new ArrayList<>();
        List<Double> perc = new ArrayList<>();
        List<String> indulasok = new ArrayList<>();

        File inputFile = new File("vonat.txt");

        try (Scanner scanner = new Scanner(inputFile)) {
            scanner.nextLine();
            while (scanner.hasNextLine()) {
                String aktualisSor = scanner.nextLine();
                String[] darabolt = aktualisSor.split("\t");
                sorszamok.add(Double.parseDouble(darabolt[0]));
                allomasok.add(Double.parseDouble(darabolt[1]));
                ora.add(Double.parseDouble(darabolt[2]));
                perc.add(Double.parseDouble(darabolt[3]));
                indulasok.add(darabolt[4]);
            }

            List<Double> allomasokUQ = new ArrayList<>();
            List<Double> vonatokUQ = new ArrayList<>();

            for (Double allomas:allomasok)
            {
                if(allomasokUQ.contains(allomas)==false)
                {
                    allomasokUQ.add(allomas);
                }
            }

            for (Double vonat:sorszamok)
            {
                if(vonatokUQ.contains(vonat)==false)
                {
                    vonatokUQ.add(vonat);
                }
            }

            System.out.println("2. feladat");
            System.out.println("Az állomások száma: " + allomasokUQ.size());
            System.out.println("A vonatok száma: " + vonatokUQ.size());


            System.out.println("4. feladat");
            System.out.println("Adja meg egy vonat azonosítóját!");
            Scanner voa = new Scanner(System.in);
            String beVoa = voa.nextLine();

            System.out.println("Adjon meg egy időpontot (óra perc) !");
            Scanner ido = new Scanner(System.in);
            String beIdo = voa.nextLine();

        } catch (FileNotFoundException exception) {
            System.err.print("Fájl nem található!");
            return;
        }
    }
}
